## Data Visualization Final Assignment

Final assignment of Data visualization with Python contains 4 questions where Questions 1 and 2 are on bar charts. Questions 3 and 4 are on Choropleth maps generated using Folium.

The [notebook](Data_Visualization_Final_Assingment.ipynb) has detailed descriptions of the questions and answers. 