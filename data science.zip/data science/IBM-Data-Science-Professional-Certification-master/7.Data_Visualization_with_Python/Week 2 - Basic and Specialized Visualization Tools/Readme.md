# Basic and Specialized Visualization Tools

**Instructor: Alex Aklson**

## Key Concepts

Create with Matplotlib
- Area plots
- Histograms
- Bar charts
- Pie charts
- Box plots
- Scatter plots
- Bubble plots

Many Data Scientists are vocal about how Pie charts don't convey information correctly and believe that a Bar chart can do the same but in a more informative and effective way.

Bubble plots

They are a variation of scatter plots displaying 3 dimensions (x,y,z)