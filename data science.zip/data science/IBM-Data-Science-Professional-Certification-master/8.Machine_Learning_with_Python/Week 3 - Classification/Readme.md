# Classification

## Key Concepts
- To understand different Classification methods.
- To apply Classification algorithms on various datasets to solve real world problems.
- To understand evaluation methods in Classification.

## Classification methods
- K-Nearest Neighbours
- Decision Trees
- Logistic Regression
- Support Vector Machine