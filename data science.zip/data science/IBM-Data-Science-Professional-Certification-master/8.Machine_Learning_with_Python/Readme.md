# Machine Learning with Python
<br>

<p align="center">
	<img src="https://raw.githubusercontent.com/Thomas-George-T/IBM-Data-Science-Professional-Certification/master/ibm.svg" title="IBM" alt="IBM" />
</p>

<br>

**Instructors: SAEED AGHABOZORGI, Joseph Santarcangelo**

**Course link:** [Machine Learning with Python](https://www.coursera.org/learn/machine-learning-with-python/)

## Program Overview
- Introduction to Machine Learning
- Regression
- Classification
- Clustering
- Recommendation Systems
- Final Assignment
