# Regression

**Instructors: SAEED AGHABOZORGI & Joseph Santarcangelo**

In this week, you will get a brief intro to regression. You learn about Linear, Non-linear, Simple and Multiple regression, and their applications. You apply all these methods on two different datasets, in the lab part. Also, you learn how to evaluate your regression model, and calculate its accuracy

# Key Concepts
- To understand the basics of regression
- To apply Simple and Multiple, Linear and Non-Linear Regression on a dataset for estimation.