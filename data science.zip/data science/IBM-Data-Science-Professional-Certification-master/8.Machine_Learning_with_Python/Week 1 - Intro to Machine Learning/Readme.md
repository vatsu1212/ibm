# Introduction to Machine Learning

**Instructors: SAEED AGHABOZORGI & Joseph Santarcangelo**

In this week, you will learn about applications of Machine Learning in different fields such as health care, banking, telecommunication, and so on. You’ll get a general overview of Machine Learning topics such as supervised vs unsupervised learning, and the usage of each algorithm. Also, you understand the advantage of using Python libraries for implementing Machine Learning models.


## Key Concepts
- To give examples of Machine Learning
- To demonstrate the Python libraries for Machine Learning
- To classify Supervised vs. Unsupervised algorithms
