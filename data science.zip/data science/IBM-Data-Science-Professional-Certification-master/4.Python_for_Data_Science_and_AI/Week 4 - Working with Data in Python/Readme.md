# Working with Data in Python

## Key Concepts
- Demonstrate an open function to create and identify a file object.
- Understand how to use pandas for library and data analysis by using commands.
- Demonstrate how to create a text file by using the open function.
- Demonstrate how to use NumPy to create multi-dimensional arrays.

