# Python Data Structures

## Key Concepts
1. Understand tuples and lists by describing and manipulating tuple combinations and list data structures.
2. Demonstrate understanding of dictionaries by writing structures with correct keys and values.
3. Understand the differences between sets, tuples, and lists by creating sets.