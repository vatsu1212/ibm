# Python Basics

## Key Concepts
- Demonstrate an understanding of types in python by converting/casting data types: strings, floats, integers.
- Interpret variables and solve expressions by applying mathematical operations.
- Describe how to manipulate strings by using a variety of methods and operations.