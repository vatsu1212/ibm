# Open Source Tools

This week, you will learn about three popular tools used in data science: GitHub, Jupyter Notebooks, and RStudio IDE. You will become familiar with the features of each tool, and what makes these tools so popular among data scientists today.

## Key Concepts
- Explain how to use GitHub to create and manage source code for data science projects.
- Describe the features of Jupyter Notebook that make it popular for data science projects.
- Describe the features of RStudio IDE that make it popular for data science projects.

