# Tools for Data Science

<br>

<p align="center">
	<img src="https://raw.githubusercontent.com/Thomas-George-T/IBM-Data-Science-Professional-Certification/master/ibm.svg" title="IBM" alt="IBM" />
</p>

<br>

**Instructors: Romeo Kienzler, Svetlana Levitan**

**Course link:** [IBM Tools for Data Science](https://www.coursera.org/learn/open-source-tools-for-data-science)

## Key Concepts

- Data Scientist's Toolkit
- Open Source Tools
- IBM Tools for Data Science
