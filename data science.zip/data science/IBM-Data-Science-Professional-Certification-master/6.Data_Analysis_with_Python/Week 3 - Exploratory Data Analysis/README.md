# Exploratory Data Analysis
Preliminary step in Data Analysis is to:
- Summarize main characteristics of the data.
- Gain better understanding of the data set.
- Uncover relationships between the variables.
- Extract important variables.