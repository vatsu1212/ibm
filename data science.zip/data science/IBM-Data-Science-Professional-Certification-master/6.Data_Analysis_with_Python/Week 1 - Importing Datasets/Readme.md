# Importing Datasets

## Key Concepts
- Understanding the Data
- Importing and Exporting Data in Python
- Getting Started Analyzing Data in Python
- Python Packages for Data Science