# Data Wrangling

## Key Concepts
- Identify and Handle Missing Values
- Data Formatting
- Data Normalization
- Binning
- Indicator variables
