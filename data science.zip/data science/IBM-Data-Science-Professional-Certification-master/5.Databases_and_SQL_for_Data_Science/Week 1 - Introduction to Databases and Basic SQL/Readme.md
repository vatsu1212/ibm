# Week 1 - Introduction to Databases and Basic SQL

## Key Concepts
- Explain SQL and Relational Databases
- Create a database instance on the Cloud
- Learn how to write basic SQL statements
- Practice basic SQL statements hands-on on a live database