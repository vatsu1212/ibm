# Databases and SQL for Data Science

<br>

<p align="center">
 <img src="https://raw.githubusercontent.com/Thomas-George-T/IBM-Data-Science-Professional-Certification/master/ibm.svg" title="IBM logo" alt = "IBM logo" />
</p>

<br>

**Instructors:Rav Ahuja**

Course link: [Databases and SQL for Data Science](https://www.coursera.org/learn/sql-data-science)

## Program Overview
- Week 1: Introduction to Databases and Basic SQL
- Week 2: Advanced SQL
- Week 3: Accessing Databases using Python
- Week 4: Course Assignment