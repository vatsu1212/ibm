# Peer-graded Assignment: Peer Reviewed Assignment

**Problem 1: Find the total number of crimes recorded in the Crime table Take a screenshot showing the SQL query and its results. Upload the JPEG (.jpg) file below for your peers to review.**

**Problem 2: Retrieve first 10 rows from the CRIME table**

**Problem 3: How many crimes involve an arrest**

**Problem 4: Which unique types of crimes have been recorded at a GAS STATION?**

**Problem 5: In the CENUS_DATA table list all community areas whose names start with the letter ‘B’.**

**Problem 6: List the schools in Community Areas 10 to 15 that are healthy school certified?**

**Problem 7: What is the average school Safety Score?**

**Problem 8: List the top 5 Community Areas by average College Enrollments (number of students)**

**Problem 9: Use a sub-query to determine which Community Area has the least value for Safety Score?**

**Problem 10: Find the Per Capita Income of the Community Area which has a school Safety Score of 1.**